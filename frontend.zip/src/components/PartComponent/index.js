export { PartComponent } from "./PartComponent";
