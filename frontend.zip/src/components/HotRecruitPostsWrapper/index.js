export { HotRecruitPostsWrapper } from "./HotRecruitPostsWrapper";
