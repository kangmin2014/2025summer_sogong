export { FirstDetail } from "./FirstDetail";
