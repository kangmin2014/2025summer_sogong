export { SecondDetail } from "./SecondDetail";
