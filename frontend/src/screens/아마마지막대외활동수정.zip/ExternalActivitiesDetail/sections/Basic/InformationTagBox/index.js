export { InformationTagBox } from "./InformationTagBox";
