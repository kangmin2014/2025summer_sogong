export { DetailBox } from "./DetailBox";
