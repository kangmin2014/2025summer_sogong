import React from "react";
import "./ApplyButton.css";

export const ApplyButton = () => {
  return (
    <div className="apply-button">
      <div className="text">신청하기</div>
    </div>
  );
};