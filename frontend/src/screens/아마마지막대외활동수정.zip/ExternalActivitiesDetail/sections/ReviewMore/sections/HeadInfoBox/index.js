export { HeadInfoBox } from "./HeadInfoBox";
