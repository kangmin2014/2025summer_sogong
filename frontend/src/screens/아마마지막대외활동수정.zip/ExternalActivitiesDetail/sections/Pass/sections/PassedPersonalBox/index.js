export { PassedPersonalBox } from "./PassedPersonalBox";
